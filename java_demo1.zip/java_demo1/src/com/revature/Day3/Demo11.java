package com.revature.Day3;

public class Demo11 {

    static {
        System.out.println("static block");
    }

    public static void main(String[] args) {
        System.out.println("main method");
    }
}