package com.revature.Day1;

public class Demo20 {
    public static void main(String[] args) {
                int num = 5;
                for(int i = 1; i <= 5; ++i)
                {
                    System.out.printf("%d * %d = %d \n", num, i, num * i);
                }
            }
        }