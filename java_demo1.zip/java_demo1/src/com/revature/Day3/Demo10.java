package com.revature.Day3;

class Customer{
    public int custId;
    public String customerName;
    public static String companyName = "revature";

    public Customer(int custId, String name){
        this.custId = custId;
        this.customerName = name;
    }

    public void printInfo(){
        System.out.println("Id: "+ custId+ ", customer name: "+ customerName+", company name: "+ companyName);
    }
}

public class Demo10 {
    public static void main(String[] args) {
        Customer customer = new Customer(1, "Mark");
        Customer customer2= new Customer(2, "Paul");

        customer.printInfo();
        customer2.printInfo();
    }
}
