package com.revature.classExercises;

//Write a program to sum first n even numbers using a while loop.

public class Q1 {
    public static void main(String[] args) {
        int sum = 0;
        int n = 4;
        for (int i = 0; i < n; i++) {
            sum = sum + (2 * i);
        }
        System.out.println("sum of even number is : " + sum);
    }
}


//
//
//
//    public static void main(String[] args) {
//        int num = 1;
//        int max = 100;
//        int total = 0;
//        while (num < max) {
//            if (num % 2 == 0){
//                total = num + total;
//            }
//            num++;
//        }
//        System.out.println(total);
//    }
//    }
