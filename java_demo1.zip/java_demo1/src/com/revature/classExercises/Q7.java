package com.revature.classExercises;

public class Q7 {
}
