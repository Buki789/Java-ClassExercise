package com.revature.classExercises;

public class Q3 {
    public static void main(String[] args) {
        int number = 10;
        for (int i = 10; i >= 1; i--) {
            System.out.println(number + " x " + i + " = " + number * i);

        }
    }

}
