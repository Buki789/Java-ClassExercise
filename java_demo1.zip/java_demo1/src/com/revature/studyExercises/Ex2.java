package com.revature.studyExercises;

public class Ex2 {
    public static void main(String[] args) {

        String yourName = "Bukola";
        int yearNow = 2002;
        int birthYear = 1973;

        System.out.println(yourName + " You are " + (yearNow - birthYear) + " Years today 'Happy BirthDay' ");



    }
}
