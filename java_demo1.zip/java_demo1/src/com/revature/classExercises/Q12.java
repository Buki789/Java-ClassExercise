package com.revature.classExercises;

public class Q12 {
    public static void main(String[] args) {
        // What can be done using one type of loop can also be done using the other two types of loops - True or False.
        System.out.println("True");

    }
}
