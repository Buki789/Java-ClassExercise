package com.revature.studyExercises;

public class Ex10 {
    public static void main(String[] args) {

        double tuna;
        tuna = 5.96;
        System.out.print("I want ");
        System.out.print(tuna);
        System.out.println(" movies");
        System.out.println("apples");
    }

}
