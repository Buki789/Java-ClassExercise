package com.revature.studyExercises;
//Throws is keyword in Java which is used to suppress the errors/ exceptions. And it should write after the main method itself
public class Day7_ex2 {

}
