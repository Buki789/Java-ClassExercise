package com.revature.Day4;

interface RBI{
    void deposit();
    void withdraw();
}

class DXCBank implements RBI{

    @Override
    public void deposit() {

    }

    @Override
    public void withdraw() {

    }
}



public class Demo5 {
    public static void main(String[] args) {

    }
}
