package com.revature.studyExercises;
import java.util.Scanner;
//This code uses scanner method to get a basic calculator , two mumbers from user and adds them together.
public class Ex11a {
    public static void main(String[] args) {
        Scanner Buki = new Scanner(System.in);
        double firstnum, secondnum, answer;
        System.out.println("Enter first num: ");
        firstnum = Buki.nextDouble();
        System.out.println("Enter second num: ");
        secondnum = Buki.nextDouble();
        answer = firstnum + secondnum;
        System.out.println(answer);

    }
}
