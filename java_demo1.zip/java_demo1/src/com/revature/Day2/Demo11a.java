//package com.revature.Day2;
//
//class Employee{
//    // class attributes / ccharacterstics / variables
//    private String firstName;
//    private String lastName;
//    private String admissionYear;
//    private String course;
//    private int age;
//
//    // class behaviour
//    public void getccharacteristics(){
//        System.out.println("campus....");
//    }
//
//    public void stop(){
//        System.out.println("classes...");
//    }
//}
//
//public class Demo11a {
//    public static void main(String[] args) {
//        Employee employeeObj = new Employee();
//        employeeObj.drive();
//        employeeObj.stop();
//    }
//}
//
//// Dog, Student, Employee



