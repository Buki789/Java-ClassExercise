package com.revature.Day1;

public class Demo4 {
    public static void main(String[] args) {

        int a = 40;
        int b = 20;

        int addition = a + b;
        int subtract = a - b;
        int multiply = a * b;
        int divide = a / b;

        System.out.println(addition);
        System.out.println(subtract);
        System.out.println(multiply);
        System.out.println(divide);

        String str1 = "10";
        String str2 = "20";
        String result = str1 + str2;
        System.out.println(result);

        int x = 10;
        int y = 20;
        String z = "Hello";
        int e = 10;
        int f = 20;


        System.out.println(x + y + z + (e + f));
    }
}
