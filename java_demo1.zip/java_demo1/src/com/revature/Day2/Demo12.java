package com.revature.Day2;

class Person {
    public String firstName;
    public String lastName;
    public int age;
    public String country;
    public String email;
    public String phone;

    public void getFullName() {
        System.out.println(firstName + " " + lastName);
    }

    public void getAge() {
        System.out.println("I am " + age + " years old");
    }

    public void getContactInfo() {
        System.out.println("you can contract me on " + phone);
    }
}

public class Demo12 {
    public static void main(String[] args) {
        Person person = new Person();
        person.firstName = "Mark";
        person.lastName = "Watson";
        person.age = 30;
        person.phone = "999999";
        person.email = "m@gmail.com";

        person.getFullName();
        person.getAge();
        person.getContactInfo();
    }
}


