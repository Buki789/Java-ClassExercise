package com.revature.studyExercises;
// This program writes a simple while loop
public class Ex12b {
    public static void main(String[] args) {
        int counter = 0;
//while the counter is less than 10 print until less than 10, starting from zero. the ++ adds an increment of one until it reaches less than ten
        while (counter < 10){
            System.out.println(counter);
            counter++;

        }
    }
}
// byte age = 30;
//Date now = new Date();
//sout(now)
