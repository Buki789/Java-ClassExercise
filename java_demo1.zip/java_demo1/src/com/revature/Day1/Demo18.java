package com.revature.Day1;

public class Demo18 {
    public static void main(String[] args) {
        int n = 7;
        for (int k = 1; k <= 5; k++) {
            for (int i = (5 + 2); i > k; --i) {
                System.out.print(" ");
            }
            for (int j = 2; j <= k; ++j) {
                System.out.print(" *");
            }
            System.out.println();
        }
    }
}


