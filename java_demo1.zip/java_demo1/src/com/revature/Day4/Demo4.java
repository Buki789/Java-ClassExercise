package com.revature.Day4;

interface IEmployee {
    void print();
}

class Employee implements IEmployee {
    public void display() {
        System.out.println("class display method");
    }

    @Override
    public void print() {
        System.out.println("interface print method");
    }
}

public class Demo4 {
    public static void main(String[] args) {
        Employee employee = new Employee();
        employee.display();
        employee.print();

        //IEmployee iEmployee = new IEmployee();
    }
}
