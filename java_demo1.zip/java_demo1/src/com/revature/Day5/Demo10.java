package com.revature.Day5;

public class Demo10 {
        public static void main(String[] args) {
            StringBuffer sb = new StringBuffer("Hello");
            sb.append("World");
            System.out.println(sb); // HelloWorld
        }

    }
