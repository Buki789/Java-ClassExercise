//package com.revature.Day5;
//
//public class Demo {
//    String s1 = "Hello Tutorials Point";
//    String upperCase = s1.toUpperCase();
//      System.out.println(s1);
//}
//}
