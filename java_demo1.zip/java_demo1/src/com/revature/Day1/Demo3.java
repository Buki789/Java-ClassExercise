package com.revature.Day1;

public class Demo3 {
    public static void main(String[] args) {
        int a = 10;
        int b = 1000;
        float c = 10.1f;
        double d = 10.23;
        boolean e = true;
        char f = 'A';
        String g = "hello";
    }
}
