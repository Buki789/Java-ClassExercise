package com.revature.classExercises;

public class Q9_all_day_2_answeres {
    public static void main(String[] args) {
    }
{
    //Write a program to sum first n even numbers using a while loop.
    int num = 1;
    int max = 100;
    int total = 0;
    while (num < max) {
        if (num % 2 == 0){
            total = num + total;
        }
        num++;
    }
    System.out.println(total);
}

    public static void Q10()
    {
        //Write a program to print the multiplication table of a given number n.
        int givenNum = 5;
        int mulMax = 12;
        int myNum = 0;
        do {
            System.out.print(givenNum + " X " + mulMax + " = ");
            System.out.println(givenNum * mulMax);
            mulMax++;
        } while (mulMax <= mulMax);
    }

    public static void ex3() {
        //Write a program to print a multiplication table of 10 in reverse order.
        int givenNum = 5;
        int multiplierMax = 12;

        do {
            System.out.print(givenNum + " X " + multiplierMax + " = ");
            System.out.println(givenNum * multiplierMax);
            multiplierMax--;
        } while (multiplierMax >= 0);

    }

    public static void ex4() {
        //Write a program to find the factorial of a given number using for loops.
        int num = 5;
        int total = 0;

        for (int i = num; i >= 1; i--) {
            if (i == 5)
                total += 5;
            else if (i < 5)
                total *= i;
        }
        System.out.println("Factorial of " + num + " : " + total);
    }

    public static void ex5() {
        //Repeat problem 5 using a while loop.
        int setNum = 5;
        int num = setNum;
        int total = 0;
        while (num > 0) {
            if (num == 5) {
                total +=5;
            } else if (num < 5) {
                total *= num;
            }
            num--;
        }
        System.out.println("Factorial of " + setNum + " : " + total);
    }

    public static void ex7() {
        // What can be done using one type of loop can also be done using the other two types of loops - True or False.
        System.out.println("True");
    }

    public static void ex8() {
        //Write a program to calculate the sum of the numbers occurring in the multiplication table of 8.
        int eight = 8;
        int multiMax = 12;
        int total = 0;
        for (int i = 0; i <= multiMax; i++) {
            total += (eight * i);
        }
        System.out.println("Total of all results" + " : " + total);
    }

}

