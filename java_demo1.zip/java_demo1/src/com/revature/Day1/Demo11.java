package com.revature.Day1;

public class Demo11 {
    public static void main(String[] args) {
//start from 0 to 11 and keep incrementing by one
        for (int i=0;i<11;i++) {
            System.out.println(i);
        }
        System.out.println("*********");//puts a break between the code
//start from 10 to 0 and keep decreasing by one
        for (int i = 10; i > 0; i--) {
            System.out.println(i);
        }
    }
}
