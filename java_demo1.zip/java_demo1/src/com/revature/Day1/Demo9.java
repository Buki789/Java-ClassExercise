package com.revature.Day1;

public class Demo9 {
    public static void main(String[] args) {

        String number = "three";
        switch (number){
            case "three":
                System.out.println(3);
                break;
        }
    }
}
