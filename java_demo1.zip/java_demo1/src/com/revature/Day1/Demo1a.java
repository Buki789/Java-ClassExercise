package com.revature.Day1;

public class Demo1a {
    public static void main(String[] args) {
        System.out.println("Hello how are You?");
        System.out.println("Hello World!");
        System.out.println("I am learning Java.");
        System.out.println("It is awesome!");
        System.out.println(3+3);
        System.out.print("Hello how are You?");
        System.out.print("Hello World!");
        System.out.print("I am learning Java.");
        System.out.print("It is awesome!");
        /* The code below will print the words Hello World
to the screen, and it is amazing */

        System.out.println("Hello World");
    }
}
