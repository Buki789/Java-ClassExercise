package com.revature.studyExercises;
//if statements(this simple if else statement tests if the code is true or false)
public class Ex12 {
//    public static void main(String[] args) {
//        int test = 6;
//        if (test ==7) {
//            System.out.println("yes");//if the condition is true that test is equal to 2 then print yes otherwise print no
//        }else{
//            System.out.println("no");
//            /* you can also use the double && operator which means both conditions have to be true or the || which is either condition is true to process i.e
//            boy = 18;
//            girl = 80;
//            if(boy > 10 && girl <40) print "you can enter"
//            else print ("you cannot enter")
//             */
//        }
//    }

    public static void main(String[] args) {
        int boy, girl;
        boy = 18;
        girl = 40;
        if(boy < 10 || girl > 40) {
            System.out.println("You can enter");
        }else{
            System.out.println("You cannot enter");
        }

    }
}

