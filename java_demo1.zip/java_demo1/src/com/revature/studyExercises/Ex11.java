package com.revature.studyExercises;
//How to import scanner
import java.util.Scanner; // this requires user to input a value from the keyboard that is stored
                           //in a variable
public class Ex11 {
    public static void main(String[] args) {
        Scanner Buki = new Scanner(System.in);
        System.out.println(Buki.nextLine());

    }
}
