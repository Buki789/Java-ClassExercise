package com.revature.Day7;

public class Demo12 {
    public static void main(String[] args) {
        try {
            dosomething();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void dosomething() throws Exception {
        doSomethingElse();
    }

    public static void doSomethingElse() throws Exception {
        doSomethingSomethingElse();
    }

    public static void doSomethingSomethingElse() throws Exception {
        throw new Exception();
    }
}