package com.revature.Day4;

interface IBankAccount{
    boolean deposit(int amount);
    boolean withdraw(int amount);
    void getBalance();
}

/***
 * using interface i am forcing my class to implement required methods
 */
class SavingAccount implements IBankAccount{
    // local variable to keep the track of balance
    private int _balance;
    // local variable to track the per day limit
    private int _perDayLimit;

    @Override
    public boolean deposit(int amount) {
        _balance += amount;
        System.out.println("successfully deposit: "+ amount);
        return true;
    }

    @Override
    public boolean withdraw(int amount) {
        // check the amount request for withdraw should be more then balance
        if(_balance < amount){
            System.out.println("insufficient fund");
            return false;
        }
        // limit 5000
        // check the per day limit should more then 5000
        else if(_perDayLimit + amount > 5000){
            System.out.println("withdraw attempt failed, you have exceeded per day limit");
            return false;
        }
        else{
            // reducing the balance with amount withdraw
            _balance -= amount;
            // adding amount to per day limit
            _perDayLimit += amount;
            System.out.println("successfully withdraw: "+ amount);
            return true;
        }
    }

    @Override
    public void getBalance() {
        System.out.println("saving account balance: "+ _balance);
    }
}

class CurrentAccount implements IBankAccount{
    private int _balance;

    @Override
    public boolean deposit(int amount) {
        _balance += amount;
        System.out.println("successfully deposit: "+ amount);
        return true;
    }

    @Override
    public boolean withdraw(int amount) {
        if(_balance < amount){
            System.out.println("insufficient fund");
            return false;
        }else{
            _balance -= amount;
            System.out.println("successfully withdraw: "+ amount);
            return true;
        }
    }

    @Override
    public void getBalance() {
        System.out.println("current account balance: "+ _balance);
    }
}

public class Demo6 {
    public static void main(String[] args) {
        IBankAccount savingAccount = new SavingAccount();
        IBankAccount currentAccount = new CurrentAccount();

        savingAccount.deposit(2000);
        savingAccount.withdraw(1000);
        savingAccount.withdraw(6000);
        savingAccount.deposit(5000);
        savingAccount.withdraw(5000);
        savingAccount.getBalance();

        System.out.println();

        currentAccount.deposit(5000);
        currentAccount.withdraw(6000);
        currentAccount.deposit(10000);
        currentAccount.withdraw(6000);
    }
}
