package com.revature.Day1;

public class Demo8 {
    public static void main(String [] args) {
//this code uses the ? and : operator to print out condition without typing it one by one
        int age = 20;

        String result = age > 18 ? "eligible" : "not eligible";
        System.out.println(result);

        int number = 6;
        String output = (number % 2 ==0) ? "even" : "odd";
        System.out.println(output);

    }
}
