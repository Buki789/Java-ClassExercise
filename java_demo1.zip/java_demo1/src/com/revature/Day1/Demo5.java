package com.revature.Day1;

public class Demo5 {
    public static void main(String[] args) {

        int a = 10;
        int b = 20;

        System.out.println(a);
        System.out.println(b);

        System.out.println(a++);
        System.out.println(a);
        System.out.println(++b);


        a = a + 1;

        a += 5;

        System.out.println(a);
    }
}
