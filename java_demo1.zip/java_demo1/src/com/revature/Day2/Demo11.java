//package com.revature.Day2;
//
//class Car{
//    // class attributes / characterstics / variables
//    private String brand;
//    private String modelName;
//    private String manufacturingYear;
//    private String color;
//    private int price;
//
//    // class behaviour
//    public void getcharacteristics(){
//        System.out.println("driving....");
//    }
//
//    public void stop(){
//        System.out.println("stoppinmg...");
//    }
//}
//
//public class Demo11 {
//    public static void main(String[] args) {
//        Car carObj = new Car();
//        carObj.drive();
//        carObj.stop();
//    }
//}
//
//// Dog, Student, Employee
