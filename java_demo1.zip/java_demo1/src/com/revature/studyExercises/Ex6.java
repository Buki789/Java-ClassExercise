package com.revature.studyExercises;

// This program converts a Fahrenheit to celsius: Input is interactive


import javax.swing.*;  //this imports the interactive window to put values to be converted

public class Ex6 {
    public static void main(String[] args) {
    String fahrenheitString;
    double fahrenheit;
    double celsius;
    fahrenheitString = JOptionPane.showInputDialog( //gets interactive user input
            "Enter Fahrenheit temperature: "); //type the words you want to appear in the dialogue box on the users screen
    fahrenheit = Double.parseDouble(fahrenheitString);  //converts string to double: using Double class method
    celsius = (fahrenheit - 32) * (5.0 / 9.0);  //calculates celsius equivalent
    System.out.println("Fahrenheit temperature:" + fahrenheit);
    System.out.println("Celsius temperature:" + celsius);
    System.exit(0);


}
}
