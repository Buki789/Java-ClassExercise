package com.revature.Day7;

public class Demo11 {
    public static void main(String[] args) {
        int a  =10;
        int b = 20;
        int c = 30;

        try{
            c = a / b;
        }catch (ArithmeticException ex){

        }catch (NullPointerException | NumberFormatException e){

        }catch (Exception ex){

        }
    }
}
