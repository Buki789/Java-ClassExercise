package com.revature.studyExercises;

public class Ex8 {

    public static void main(String[] args) {
        int originalNumber = 7;
        double calculatedNumber;

        calculatedNumber = (originalNumber * 2);
        System.out.println("CalculatedAnswer " + calculatedNumber);

    }
}
