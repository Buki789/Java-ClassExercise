package com.revature.Day2;

public class Demo5 {
    public static void main(String[] args) {

        int number = 5;
        for(int i =1; i<=10;i++) {
            System.out.println(number + " * " + i + " = " + number * i);
        }
}
}
