package com.revature.Day2;

public class Demo3{
        public static void main(String[] args) {
            for(int i=1;i<10;i++){
                if(i==5){
                    System.out.println("break");
                    break;
                }
                System.out.println(i);
            }
            int f = 9;
            int k = 8;
            System.out.println(f*k);
        }
}
