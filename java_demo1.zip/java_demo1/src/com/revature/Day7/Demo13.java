package com.revature.Day7;

public class Demo13 {
    public static void main(String[] args) {
        // 1st
        try{

        }catch (Exception e){

        }

        // 2n
        try{

        }catch (ArithmeticException ex){

        }catch (Exception ex){

        }

        // 3rd
        try{
            try{

            }catch (Exception ex){

            }
        }catch (Exception ex){

        }

        // 4
        try{

        }finally {

        }
    }
}
