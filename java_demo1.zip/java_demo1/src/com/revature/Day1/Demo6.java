package com.revature.Day1;

public class Demo6 {
    public static void main(String[] args) {

        int age = 15;

        if (age < 18) {
            System.out.println("eligible");
        } else
            System.out.println("not eligible");


            if(age > 18)
                System.out.println("eligible");
            else
                System.out.println("not eligible");
        }
    }

