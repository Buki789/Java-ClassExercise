package com.revature.Day1;

class Test {

    static int x = 100;
    int c = 10;

    public void addNumber() {
        int a = 10;
        int b = 20;
        System.out.println(c);
        System.out.println(x);
    }
    public void foo() {
        //System.out.println(a);

    }
}
public class Demo2 {
    public static void main(String[] args) {
        Test test = new Test();
        test.addNumber();
    }
}