package com.revature.Day8;

public class Demo8 {
    public static void main(String[] args) {
        int a = 3;
        System.out.println(a++);
        System.out.println(a);
        System.out.println(--a);
        a *= 2;
        System.out.println(a);

    }
}
