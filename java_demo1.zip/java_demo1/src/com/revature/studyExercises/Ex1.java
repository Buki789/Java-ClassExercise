package com.revature.studyExercises;

public class Ex1 {
    public static void main(String[] args) {

        int year = 1975;
        int currentyear = 2022;

        System.out.println("You are " + (currentyear - year) + " today");
    }

}










