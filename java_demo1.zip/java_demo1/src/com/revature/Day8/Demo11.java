//package com.revature.Day8;
//
//public class Demo11 {
//
//    public static void main(String[] args) {
//        boolean b = getBooleanValue();
//        if (b) {
//            foo();
//        } else {
//            bar();
//        }
//    }
//}
