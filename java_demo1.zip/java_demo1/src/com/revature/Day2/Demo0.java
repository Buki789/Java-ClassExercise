package com.revature.Day2;

public class Demo0 {
    public static void main(String[] args) {
        double tuna;
        tuna=5.28;

        System.out.print("I want ");
        System.out.print(tuna);
        System.out.println(" movies and Apples");
        System.out.println("  apples's ");


    }
}
