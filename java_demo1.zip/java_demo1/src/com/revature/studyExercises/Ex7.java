//This program calculates the number of gallons of paint needed to paint a room

package com.revature.studyExercises;

import javax.swing.*;

public class Ex7 {
    public static void main(String[] args) {
        int height1 = 9;
        int height2 = 9;
        double width1 = 19.5;
        double width2 = 20.0;
        double squarefeet;
        double numGallons;

        squarefeet = (width1 * height1 + width2 * height2) * 2;
        numGallons = squarefeet / 150;
        System.out.println("Number of Gallons: " + numGallons);
        System.exit(0);
    }

}

