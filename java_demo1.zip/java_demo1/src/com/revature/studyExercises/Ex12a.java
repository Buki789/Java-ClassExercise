package com.revature.studyExercises;

//This code uses the switch method
//This program writes a code without using the if statements. it tests one variable and depending on the
// value of the variable it gives you multiple choices to output.so you code as many possible outcomes in cases
//the int age is the variable that determines which of the cases(1-3) will print, If the int age is equal to 7 ; it will print the default
//if it is 2 it will print "you can talk"

public class Ex12a {
    public static void main(String[] args) {

        int age = 3;     //the condition
        switch (age) {
            case 1:
                System.out.println("You can crawl");
            case 2:
                System.out.println("You can walk");
            case 3:
                System.out.println("You can talk");
            case 6://this case will run by default because it is not in the case range. you can comment it out
                System.out.println("Hello");
                break;
            default:
                System.out.println("I don't know how old you are");

        }
    }
}
