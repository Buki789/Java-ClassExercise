package com.revature.Day4;

class Student {
    private int studentId;
    private String studentName;
    private int passMark = 50;

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("id cannot be -ve");
        }
        this.studentId = id;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) throws Exception {
        if(studentName.isBlank()){
            throw new Exception("name cannot be blank");
        }
        this.studentName = studentName;
    }

    public int getPassMark() {
        return passMark;
    }


}

public class Demo13 {
    public static void main(String[] args) throws Exception {
        Student student = new Student();
//        student.studentId = -1;
//        student.studentName = null;
//        student.passMark = 20;
//
//        System.out.println(student.studentId);
//        System.out.println(student.studentName);
//        System.out.println(student.passMark);

        student.setStudentId(100);
        student.setStudentName("Mark");


        System.out.println(student.getStudentId());
        System.out.println(student.getStudentName());
        System.out.println(student.getPassMark());
    }
}
