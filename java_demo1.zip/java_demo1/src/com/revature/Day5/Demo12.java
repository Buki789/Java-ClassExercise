package com.revature.Day5;

public class Demo12 {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer();
        System.out.println(sb.capacity()); // 16
        sb.append("Hello");
        System.out.println(sb.capacity()); // 16
        sb.append("Welcome to java class");
        System.out.println(sb.capacity());  // 34

        /*the default capacity of the buffer is 16, if the number of character increase from its current capacity
it increase the capicity.
(old capacity * 2) + 2

default capacity * 2 = 16

(16 * 2)+ 2 = 34
*/
    }
}


