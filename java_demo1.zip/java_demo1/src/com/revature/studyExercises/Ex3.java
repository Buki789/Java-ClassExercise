package com.revature.studyExercises;

public class Ex3 {
    public static void main(String[] args) {

        int num1 = 3;
        int num2 = 20;

        System.out.println(num1 + num2);
        System.out.println(num1 - num2);

        //  % means modulus or remainder
        System.out.println(num2 % num1);

        System.out.println(num1 * num2);
        System.out.println(num2 / num1);

        // -num1 means the negative of the number i.e num1 is 4 them -num1 is -ve4
        System.out.println(-num1);

        System.out.println("Answer is " + (num1 + num2));
        System.out.println("Answer is " + (num1 - num2));

        //  % means modulus or remainder
        System.out.println("Answer is " + (num2 % num1));

        System.out.println("Answer is " + (num1 * num2));
        System.out.println("Answer is " + (num2 / num1));

        // -num1 means the negative of the number i.e num1 is 4 them -num1 is -ve4
        System.out.println("Answer is " + (-num1));


    }

}
