package com.revature.ClassExercise;

public class preventCreationOfSecondObject {
}
