package com.revature.studyExercises;

import javax.swing.*;

import static java.lang.Integer.parseInt;

public class Ex9 {
    public static void main(String[] args) {
        int originalNumber;
        String originalNumberString;
        int calculatedAnswer;
        originalNumberString = JOptionPane.showInputDialog(
                "Enter number to double or 0 to end: ");
        originalNumber = parseInt(originalNumberString);
        while (originalNumber != 0);


            calculatedAnswer = (originalNumber * 2);
            System.out.println(originalNumber + " doubled is " + calculatedAnswer);
            originalNumberString = JOptionPane.showInputDialog(
                    "Enter number to double or 0 to end: ");
            originalNumber = Integer.parseInt(originalNumberString);
            System.exit(0);

        }
    }


