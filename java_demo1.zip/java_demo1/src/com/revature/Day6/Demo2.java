package com.revature.Day6;

public class Demo2 {
    public static void main(String[] args) {
        int a = 20;
        int b = 0;
        int c = 0;

        try {
            c = a / b;
            System.out.println(c);
        }

        catch (ArithmeticException ex) {
            System.out.println("invalid number");
        }
        catch (Exception ex) {
            System.out.println("exception occur");
        }
        finally {
            System.out.println("finally");
        }

    }
}