package com.revature.studyExercises;
//Narrow casting changing double to int
public class Ex12d {
    // Narrowing casting must be done manually by placing the type in parentheses in front of the value:

        public static void main(String[] args) {
            double myDouble = 9.78d;
            int myInt = (int) myDouble; // Manual casting: double to int

            System.out.println(myDouble);   // Outputs 9.78
            System.out.println(myInt);      // Outputs 9
        }
        int sum1 = 100 + 50;
        int sum2 = sum1+250;
        int sum3 = sum2 + sum2;     // 800 (400 + 400)
        //    System.out.println()


    }
