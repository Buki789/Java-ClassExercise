//package com.revature.studyExercises;
////Write a Java program to iterate a linked list in reverse order.
//
//import org.w3c.dom.Node;
//public void reverseList() {
//    Node prev = null;
//    Node curr = null;
//    Node next = head;
//
//    while(next != null) {
//        curr = next;
//        next = curr.getNext();
//        curr.setNext(prev);
//        prev = curr;
//        }
//    head = curr
//
//
//
//public class Quest4 {
//    public static void main(String[] args) {
//        Linked a = new Linked();
//
//        Node head = null;
//
//        head = a.insert(12, head);
//        head = a.insert(99, head);
//        head = a.insert(8, head);
//        head = a.insert(39, head);
//        head = a.insert(5, head);
//
//        head = a.reverseIteratively(head);
//        a.printList(head);
//    }
//}
