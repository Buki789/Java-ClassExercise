package com.revature.Day7;

import java.io.IOException;

class Calculator{

    public void test() throws ArithmeticException, NullPointerException, IOException {

    }
}

public class Demo7 {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        try {
            calculator.test();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (ArithmeticException ex){

        }catch (NullPointerException ex){

        }
    }

}
