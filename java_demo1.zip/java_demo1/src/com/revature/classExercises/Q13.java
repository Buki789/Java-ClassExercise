package com.revature.classExercises;

public class Q13 {
    public static void main(String[] args) {
        //Write a program to calculate the sum of the numbers occurring in the multiplication table of 10.
        int ten = 10;
        int multiMax = 12;
        int total = 0;
        for (int i = 0; i <= multiMax; i++) {
            total += (ten * i);
        }
        System.out.println("Total of all results" + " : " + total);
    }
}

