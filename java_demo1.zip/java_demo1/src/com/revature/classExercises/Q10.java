package com.revature.classExercises;

public class Q10 {
    public static void main(String[] args) {
        //Write a program to print a multiplication table of 5 in reverse order.
        int givenNum = 5;
        int multiplierMax = 12;

        do {
            System.out.print(givenNum + " X " + multiplierMax + " = ");
            System.out.println(givenNum * multiplierMax);
            multiplierMax--;
        } while (multiplierMax >= 0);


    }
}
