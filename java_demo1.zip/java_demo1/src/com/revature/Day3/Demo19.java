package com.revature.Day3;

final class Parent10{

}

//class Child10 extends Parent10{

public class Demo19 {
    public static void main(String[] args) {

    }
}
