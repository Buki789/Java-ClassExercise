package com.revature.Day3;

class Parent2{
    public Parent2(int x){
        System.out.println("parent constructor called: "+ x);
    }
}

class Child2 extends Parent2{
    public Child2(int a){
        super(a);
        System.out.println("child constructor called");
    }
}


public class Demo5 {
    public static void main(String[] args) {
        Child2 c = new Child2(100);
    }
}