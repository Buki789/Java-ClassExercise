package com.revature.studyExercises;

import java.util.Scanner;
public class Ex11b {

    public static void main(String[] args) {
        Scanner Buki = new Scanner(System.in);

        int boys, girls, total;
        boys = 8;
        girls = 13;
        total = boys + girls;
        System.out.println(total);
/* the increment operator variable ++ adds one to the variable
you can do it before the variable e.g. ++boys or (--boys) which outputs 9(this is called pre incrementing) it changes
the value of the variable before it uses it. Post incrementing boys++(here the variable is used as five before incrementing it)
so  if you do a print the value will be 5 to see the post increment you do a print again, also (boys += 8) is a way to add 8 to boys
others are boys *= 8, -= 8,  */
    }
}
