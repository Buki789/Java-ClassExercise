package com.revature.studyExercises;

public class Ex4 {
    public static void main(String[] args) {
        int count = 5;
        int num1 = 3;
        int num2 = 30;
        int answer1 = 7;
        System.out.println(answer1 + (num1 * num2));
        System.out.println(count += num1);
        System.out.println(count = count + num1);
        System.out.println(count + num1);
        System.out.println(count = num1 + num2 / 2);

    }
}
