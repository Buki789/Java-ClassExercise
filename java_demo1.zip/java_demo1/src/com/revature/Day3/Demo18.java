package com.revature.Day3;

class Bike{
    public final void drive(){
        System.out.println("driving...");
    }
}

class Honda extends Bike{
//    @Override
//    public void drive() {
//        System.out.println("not driving...");
//    }
}

public class Demo18 {
    public static void main(String[] args) {
        Honda honda = new Honda();
        honda.drive();
    }
}
