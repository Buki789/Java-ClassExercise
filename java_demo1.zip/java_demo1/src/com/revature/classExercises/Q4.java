package com.revature.classExercises;

public class Q4 {
    public static void main(String[] args) {
        int number = 5;
        // Write a program to find the factorial of a given number using for loops
        // what is factorial number
        // n = n * n-1 * n-2 ......
        // 5 = 5*4*3*2* 1 = 120
        int i = 1;
        int factorial = 1;
        while (i <= number) {
            factorial *= i;
            i++;
        }
        System.out.println(factorial);
    }
}
/*    or do it like so
}
    //Write a program to find the factorial of a given number using for loops.
    int num = 5;
    int total = 0;

        for (int i = num; i >= 1; i--) {
                if (i == 5)
                total += 5;
                else if (i < 5)
        total *= i;
        }
        System.out.println("Factorial of " + num + " : " + total);
        }
*/