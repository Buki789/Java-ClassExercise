package com.revature.Day3;

class Parent{
    public Parent(){
        System.out.println("parent constructor");
    }

    public void parentMethod(){

    }
}

class Child extends Parent{
    public Child(){
        System.out.println("child constructor");
    }

    public void childMethod(){

    }
}


public class Demo4 {
    public static void main(String[] args) {
        //Parent p = new Parent();
        Child c = new Child();
        c.childMethod();
        c.parentMethod();

        Parent p = new Parent();
        p.parentMethod();

    }
}
