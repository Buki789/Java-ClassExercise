package com.revature.classExercises;

//Write a program to print the multiplication table of a given number n.

public class Q2 {
        public static void main(String[] args) {
            int number = 5;
            for (int i = 1; i <= 10; i++) {
                System.out.println(number + " x " + i + " = " + number * i);
            }
        }
    }