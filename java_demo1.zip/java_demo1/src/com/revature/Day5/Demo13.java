package com.revature.Day5;
public class Demo13{
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Hello");
        sb.append("World");
        System.out.println(sb);
    }
}

