/*package com.revature.classExercises;

public class Q11 {
    public static void main(String[] args) {

    }
    //Write a program to find the factorial of a given number using while loops.

    int setNum = 5;
    int num = setNum;
    int total = 0;
        while (num > 0) {
        if (num == 5) {
            total +=5;
        } else if (num < 5) {
            total *= num;
        }
        num--;
    }
        System.out.println("Factorial of " + setNum + " : " + total);
}
*/