package com.revature.Day8;

public class Demo9 {
    public static void main(String[] args) {

        String[] words = {"hello", "goodbye", "aloha", "qwerty"};
        for (String w : words) {
            System.out.println(transform(w));
        }
    }

    public static String transform(String s) {
        String newStr = s.replace("e","a");
        return newStr;

    }
}
